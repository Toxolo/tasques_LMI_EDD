# Benvigut als apunts de Josep


  - Articles EDD:
    - [`Article 1`](ENTORNS/documente_1.md)
    - [`Article 2`](ENTORNS/documente_2.md)
    - [`Article 3`](ENTORNS/documente_3.md)
    - [`Article 4`](ENTORNS/documente_4.md)
    - [`Article 5`](ENTORNS/documente_5.md)
  - Articles LMI:
    - [`Article 1`](MARQUES/documentm_1.md)

![texto_alternativo](ENTORNS/imagenes/images.jpeg)