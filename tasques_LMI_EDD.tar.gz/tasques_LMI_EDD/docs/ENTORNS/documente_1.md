# Els llenguatges més importants
    JAVASCRIPT-

**Nivell d’abstracció:** Alt

**Propòsit:** Desenvolupament web (front-end i back-end), aplicacions mòbils, i més.

**Compilat/Integrat:** Interpretat

**Paradigmes:** Orientat a objectes, imperatiu, funcional

    PYTHON-

**Nivell d’abstracció:** Alt

**Propòsit:** Desenvolupament web, anàlisi de dades, intel·ligència artificial, automatització, ciències
de la computació.

**Compilat/Integrat:** Interpretat

**Paradigmes:** Orientat a objectes, imperatiu, funcional, procedimental

    TYPERSCRIPT-

**Nivell d’abstracció:** Alt

**Propòsit:** Desenvolupament web (front-end i back-end), millora de la mantenibilitat del codi
JavaScript amb tipatge estàtic.

**Compilat/Integrat:** Compilat (a JavaScript, que és interpretat pel navegador o pel servidor)

**Paradigmes:** Orientat a objectes, imperatiu, funcional

    JAVA-
**Nivell d’abstracció:** Alt

**Propòsit:** Desenvolupament d'aplicacions empresarials, aplicacions mòbils (Android), aplicacions
web.

**Compilat/Integrat:** Compilat

**Paradigmes:** Orientat a objectes, imperatiu, funcional

    C#-
**Nivell d’abstracció:** Alt

**Propòsit:** Desenvolupament d'aplicacions a Windows, desenvolupament de videojocs amb Unity,
aplicacions web.

**Compilat/Integrat:** Compilat

**Paradigmes:** Orientat a objectes, imperatiu, funcional