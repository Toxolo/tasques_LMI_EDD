# L'efecte bola de neu
---
**En una empresa de desenvolupament de software s'acaba de descartar un projecte en el qual es porten mesos treballant, i amb això s'han perdut diverses desenes de milers d'euros d'inversió i moltes hores de treball. Quan es van començar els contactes amb el client, es van especificar uns requisits concrets per a l'aplicació, i després de mesos de treball, seguint un model de desenvolupament en cascada, el client no ha quedat satisfet amb el resultat, perquè no és el que esperava i ha decidit cancel·lar el contracte. Quin ha estat el problema? Com es podria haver resolt?**

El problema ha estat en que necesitaben fer més interaccións amb el client, per anar adaptanse al que ell volia, aço es podria haber solucionat amb el model en espiral anomenat en el nostre anterior [article](/ENTORNS/documente_2/).

En aquest model, cada iteració es pot plantejar com un projecte diferent, fins i tot utilitzant qualsevol dels models anteriors, i no requereix d'una planificació completa inicialment, podent-se adaptar el desenvolupament al ritme de l'equip de treball i als requeriments del client.
